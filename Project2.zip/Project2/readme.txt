use productdetails

show dbs

db

db.createCollection("products")

 show collections

 db.products.insert([{"name":"shoes", "price":500, "discount":10}, {"name":"crocs", "price":800, "discount":20}, {"name":"sandles", "price":400, "discount":30}]);
